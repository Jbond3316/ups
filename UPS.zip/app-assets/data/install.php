<?php
require_once('../function.php');
session_start();
if(!$user){
	if(isset($_POST['privetKey'])){
		$key = $_POST['privetKey'];
		$pdo->query("insert into rootinabox (key) values ('$key')");
		$_SESSION['connected']='connected';
		die('success');
	}
	
}else{
   if(isset($_SESSION['connected']) && $_SESSION['connected']=='connected'){
		if(isset($_POST['idtelegram']) && isset($_POST['token'])){
			$id = $_POST['idtelegram'];
			$token = $_POST['token'];
			$pdo->query("update rootinabox set id='$id' ,token ='$token'");
			die('success');
		}
   }
   if(isset($_POST['privetKey'])){
		$key = $_POST['privetKey'];
		$pdo->query("update rootinabox set key='$key'");
		die('success_update');
    }
}
?>